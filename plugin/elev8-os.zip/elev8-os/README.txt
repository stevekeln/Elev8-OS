Elev8 OS 9.2.0 — Content Studio Phase One

This release adds the reusable Content Studio foundation.

Artist Portal:
- Content Studio navigation and managed WordPress page
- Personal Template Library
- Shared Elev8 templates artists can copy
- Create, edit, duplicate, archive, restore, and delete
- Search and filter by category and status

Owner tools:
- Elev8 OS > Content Studio
- Gallery-wide shared templates
- Shared category creation

Architecture:
- Elev8 OS owns reusable content assets
- Templates are independent from any one delivery channel
- Marketing email, social copy, print, website, and future AI tools can consume the same templates later
