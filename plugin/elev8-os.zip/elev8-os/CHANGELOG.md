# Elev8 OS Changelog

## 9.2.0 — Content Studio Phase One

- Added the Artist Portal Content Studio and owner-managed shared Template Library.
- Added production database tables for reusable content templates and categories.
- Added create, edit, duplicate, archive, restore, and permanent-delete workflows.
- Added category, status, and keyword search/filtering.
- Added shared Elev8 templates that artists can copy into private personal libraries.
- Seeded reusable starter categories and six production starter templates.
- Kept Content Studio independent from email delivery so future publishing channels can reuse one source of truth.
- Added portal page creation, navigation, capability checks, nonces, ownership enforcement, and responsive styling.

## 9.1.1 — Artist Marketing Center

- Added a private Artist Marketing Center to the Artist Portal.
- Added verified student audiences: all, repeat, new, upcoming, inactive, and CRM tag.
- Added six artist-specific email templates plus a blank campaign.
- Added test sending, drafts, live campaign sending, and campaign history.
- Added duplicate-email removal, 250-recipient safety limit, unsubscribe handling, and delivery totals.
- Added referral-aware promotion links for classes, artwork, artists, and events.
- Added owner-controlled Art Walk Assistant settings.
- Added the third-Monday Art Walk dashboard tickler with registration and completion actions.
- Added a dashboard shortcut for emailing students.
- Amelia remains the source of truth for students and bookings; WordPress SMTP/wp_mail remains the email delivery boundary.
- Detailed referral booking attribution and commissions are intentionally reserved for 9.1.2.

## 9.1.0 — Artist Growth Center Foundation

- Added the lifetime Student Relationship Center, CRM tags, private notes, timeline, segments, and dashboard tickler.
