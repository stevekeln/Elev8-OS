<?php

if (!defined('ABSPATH')) {
    exit;
}

require_once ELEV8_OS_DIR . 'includes/Services/class-elev8-os-identity-service.php';
require_once ELEV8_OS_DIR . 'includes/Services/class-elev8-os-settings-service.php';
require_once ELEV8_OS_DIR . 'includes/Services/class-elev8-os-notification-service.php';
require_once ELEV8_OS_DIR . 'includes/Services/class-elev8-os-activity-service.php';
require_once ELEV8_OS_DIR . 'includes/Services/class-elev8-os-opportunity-gateway.php';

/**
 * Reusable Artist Portal navigation and link data.
 *
 * Links are saved on the WordPress user so Elev8 OS owns the relationship.
 * Amelia remains one integration rather than the source of portal navigation.
 */
final class Elev8_OS_Artist_Portal_Module {

    private const META_PUBLIC_PAGE = 'elev8_os_public_artist_page_url';
    private const META_EDIT_PAGE = 'elev8_os_edit_artist_page_url';
    private const META_CLASSES = 'elev8_os_artist_classes_url';
    private const META_BOOKING = 'elev8_os_artist_booking_url';
    private const WEBSITE_PAGE_OPTION = 'elev8_os_artist_website_page_id';
    private const WEBSITE_PAGE_SLUG = 'artist-website';
    private const WEBSITE_SHORTCODE = 'elev8_artist_website';
    private const EDIT_WEBSITE_PAGE_OPTION = 'elev8_os_artist_edit_website_page_id';
    private const EDIT_WEBSITE_PAGE_SLUG = 'artist-edit-website';
    private const EDIT_WEBSITE_SHORTCODE = 'elev8_artist_edit_website';
    private const PROFILES_OPTION = 'elev8_os_artist_profiles';
    private const EMPLOYEE_META_KEY = 'elev8_os_amelia_employee_id';

    public static function init(): void {
        add_action('init', [__CLASS__, 'register_website_shortcode']);
        add_action('init', [__CLASS__, 'register_edit_website_shortcode']);
        add_action('admin_post_elev8_os_artist_save_website', [__CLASS__, 'save_artist_website']);
        add_action('wp_enqueue_scripts', [__CLASS__, 'enqueue_assets']);
        add_filter('body_class', [__CLASS__, 'body_classes']);
        add_action('wp_head', [__CLASS__, 'render_portal_shell_css'], 99);
        add_action('admin_enqueue_scripts', [__CLASS__, 'enqueue_admin_assets']);

        add_action('show_user_profile', [__CLASS__, 'render_profile_fields']);
        add_action('edit_user_profile', [__CLASS__, 'render_profile_fields']);
        add_action('personal_options_update', [__CLASS__, 'save_profile_fields']);
        add_action('edit_user_profile_update', [__CLASS__, 'save_profile_fields']);
    }

    public static function status(): string {
        return 'active';
    }

    /**
     * Give teacher-facing portal pages one application shell instead of
     * displaying the public website header and the portal navigation together.
     *
     * @param array<int,string> $classes
     * @return array<int,string>
     */
    public static function body_classes(array $classes): array {
        if (self::is_portal_request()) {
            $classes[] = 'elev8-os-portal-shell';
        }

        return array_values(array_unique($classes));
    }

    /**
     * Render a portal-only theme shell override.
     *
     * Neve can render its header through several wrapper combinations depending
     * on the Header Builder configuration. This runs only on verified Elev8 OS
     * portal pages, so it can safely hide the public theme header without
     * affecting the rest of the site.
     */
    public static function render_portal_shell_css(): void {
        if (!self::is_portal_request()) {
            return;
        }
        ?>
        <style id="elev8-os-portal-shell-css">
            body.elev8-os-portal-shell #header-grid,
            body.elev8-os-portal-shell #masthead,
            body.elev8-os-portal-shell .site-header,
            body.elev8-os-portal-shell .hfg_header,
            body.elev8-os-portal-shell header.header,
            body.elev8-os-portal-shell .header-main,
            body.elev8-os-portal-shell .header--row,
            body.elev8-os-portal-shell .nv-navbar,
            body.elev8-os-portal-shell .header-menu-sidebar,
            body.elev8-os-portal-shell .neve-main,
            body.elev8-os-portal-shell .neve-main > header,
            body.elev8-os-portal-shell .nv-page-title-wrap {
                display: none !important;
            }
            body.elev8-os-portal-shell .site-main,
            body.elev8-os-portal-shell main#content,
            body.elev8-os-portal-shell .nv-single-page-wrap {
                margin-top: 0 !important;
                padding-top: 0 !important;
            }
        </style>
        <?php
    }

    /**
     * Determine whether the current front-end request is an Elev8 OS portal page.
     */
    private static function is_portal_request(): bool {
        if (!is_user_logged_in()) {
            return false;
        }

        if (self::is_website_page() || self::is_edit_website_page()) {
            return true;
        }

        if (!class_exists('Elev8_OS_Portal_Page_Manager')) {
            return false;
        }

        foreach (['dashboard', 'classes', 'artwork', 'students', 'growth_studio', 'content_studio', 'marketing', 'waitlist', 'print_center'] as $portal_page) {
            if (Elev8_OS_Portal_Page_Manager::is_current_page($portal_page)) {
                return true;
            }
        }

        return false;
    }

    public static function enqueue_assets(): void {
        if (!is_user_logged_in()) {
            return;
        }

        $portal_pages = ['dashboard', 'classes', 'artwork', 'students', 'growth_studio', 'content_studio', 'marketing', 'waitlist', 'print_center'];
        $is_portal_page = false;
        foreach ($portal_pages as $portal_page) {
            if (Elev8_OS_Portal_Page_Manager::is_current_page($portal_page)) {
                $is_portal_page = true;
                break;
            }
        }

        if (!$is_portal_page && !self::is_website_page() && !self::is_edit_website_page()) {
            return;
        }

        wp_enqueue_style(
            'elev8-os-artist-portal',
            ELEV8_OS_URL . 'assets/css/artist-portal.css',
            [],
            ELEV8_OS_VERSION
        );

        wp_enqueue_style(
            'elev8-os-growth-studio-palette',
            ELEV8_OS_URL . 'assets/css/artist-growth-studio.css',
            ['elev8-os-artist-portal'],
            ELEV8_OS_VERSION
        );

        if (Elev8_OS_Portal_Page_Manager::is_current_page('dashboard')) {
            wp_enqueue_style(
                'elev8-os-artist-shortcut-launcher',
                ELEV8_OS_URL . 'assets/css/artist-shortcut-launcher.css',
                ['elev8-os-artist-portal'],
                ELEV8_OS_VERSION
            );
            wp_enqueue_script(
                'elev8-os-artist-shortcut-launcher',
                ELEV8_OS_URL . 'assets/js/artist-shortcut-launcher.js',
                [],
                ELEV8_OS_VERSION,
                true
            );
        }

        if (self::is_edit_website_page()) {
            wp_enqueue_script(
                'elev8-os-artist-website-preview',
                ELEV8_OS_URL . 'assets/js/artist-website-live-preview.js',
                [],
                ELEV8_OS_VERSION,
                true
            );
        }
    }

    public static function enqueue_admin_assets(string $hook): void {
        if ($hook !== 'elev8-os_page_elev8-artist-dashboard') {
            return;
        }

        wp_enqueue_style(
            'elev8-os-artist-portal',
            ELEV8_OS_URL . 'assets/css/artist-portal.css',
            [],
            ELEV8_OS_VERSION
        );
    }


    public static function register_website_shortcode(): void {
        add_shortcode(self::WEBSITE_SHORTCODE, [__CLASS__, 'website_shortcode']);
    }

    public static function register_edit_website_shortcode(): void {
        add_shortcode(self::EDIT_WEBSITE_SHORTCODE, [__CLASS__, 'edit_website_shortcode']);

        // Backward-compatible alias used by an earlier draft page.
        add_shortcode('elev8_artist_website_editor', [__CLASS__, 'edit_website_shortcode']);
    }

    public static function ensure_edit_website_page(): void {
        $page_id = (int) get_option(self::EDIT_WEBSITE_PAGE_OPTION);
        if ($page_id > 0 && get_post_status($page_id)) {
            return;
        }

        $existing = get_page_by_path(self::EDIT_WEBSITE_PAGE_SLUG);
        if ($existing instanceof WP_Post) {
            update_option(self::EDIT_WEBSITE_PAGE_OPTION, (int) $existing->ID, false);
            return;
        }

        if (!current_user_can('manage_options')) {
            return;
        }

        $page_id = wp_insert_post([
            'post_title' => __('Edit Website', 'elev8-os'),
            'post_name' => self::EDIT_WEBSITE_PAGE_SLUG,
            'post_content' => '[' . self::EDIT_WEBSITE_SHORTCODE . ']',
            'post_status' => 'publish',
            'post_type' => 'page',
            'post_author' => get_current_user_id(),
        ], true);

        if (!is_wp_error($page_id) && $page_id > 0) {
            update_option(self::EDIT_WEBSITE_PAGE_OPTION, (int) $page_id, false);
        }
    }

    public static function ensure_website_page(): void {
        $page_id = (int) get_option(self::WEBSITE_PAGE_OPTION);
        if ($page_id > 0 && get_post_status($page_id)) {
            return;
        }

        $existing = get_page_by_path(self::WEBSITE_PAGE_SLUG);
        if ($existing instanceof WP_Post) {
            update_option(self::WEBSITE_PAGE_OPTION, (int) $existing->ID, false);
            return;
        }

        if (!current_user_can('manage_options')) {
            return;
        }

        $page_id = wp_insert_post([
            'post_title' => __('My Website', 'elev8-os'),
            'post_name' => self::WEBSITE_PAGE_SLUG,
            'post_content' => '[' . self::WEBSITE_SHORTCODE . ']',
            'post_status' => 'publish',
            'post_type' => 'page',
            'post_author' => get_current_user_id(),
        ], true);

        if (!is_wp_error($page_id) && $page_id > 0) {
            update_option(self::WEBSITE_PAGE_OPTION, (int) $page_id, false);
        }
    }

    public static function website_shortcode(): string {
        if (!is_user_logged_in()) {
            return sprintf(
                '<div class="elev8-dashboard-login"><p>%1$s</p><p><a class="button" href="%2$s">%3$s</a></p></div>',
                esc_html__('Please log in to view your artist website.', 'elev8-os'),
                esc_url(wp_login_url(self::website_url())),
                esc_html__('Log In', 'elev8-os')
            );
        }

        $user = wp_get_current_user();
        $artist = self::find_artist_for_user($user);
        ob_start();
        ?>
        <div class="elev8-artist-dashboard elev8-artist-website">
            <?php self::render_navigation('website'); ?>

            <header class="elev8-dashboard-header elev8-website-header">
                <div>
                    <p class="elev8-eyebrow"><?php esc_html_e('Artist Portal', 'elev8-os'); ?></p>
                    <h1><?php esc_html_e('My Website', 'elev8-os'); ?></h1>
                    <p><?php esc_html_e('This is how customers see your public artist profile.', 'elev8-os'); ?></p>
                </div>
                <span class="elev8-dashboard-badge"><?php esc_html_e('Public preview', 'elev8-os'); ?></span>
            </header>

            <?php if (!$artist) : ?>
                <div class="elev8-dashboard-warning">
                    <p><strong><?php esc_html_e('Your account is not connected to an Amelia artist.', 'elev8-os'); ?></strong><br><?php esc_html_e('Ask an administrator to map this WordPress account to the correct Amelia employee.', 'elev8-os'); ?></p>
                </div>
            <?php else : ?>
                <?php
                $slug = self::artist_slug($artist);
                $public_url = home_url('/artists/' . $slug . '/');
                $edit_url = self::edit_website_url();
                ?>
                <section class="elev8-website-toolbar" aria-label="<?php esc_attr_e('Website actions', 'elev8-os'); ?>">
                    <div>
                        <strong><?php esc_html_e('Your public page', 'elev8-os'); ?></strong>
                        <span><?php echo esc_html($public_url); ?></span>
                    </div>
                    <div class="elev8-website-actions">
                        <button type="button" class="elev8-copy-public-link" data-link="<?php echo esc_attr($public_url); ?>"><?php esc_html_e('Copy Link', 'elev8-os'); ?></button>
                        <a class="elev8-secondary-button" href="<?php echo esc_url($public_url); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e('Open Public Page', 'elev8-os'); ?></a>
                        <a class="elev8-primary-button" href="<?php echo esc_url($edit_url); ?>"><?php esc_html_e('Manage My Website', 'elev8-os'); ?></a>
                    </div>
                </section>

                <section class="elev8-website-preview" aria-labelledby="elev8-preview-title">
                    <div class="elev8-panel-heading">
                        <div>
                            <p class="elev8-eyebrow"><?php esc_html_e('Live preview', 'elev8-os'); ?></p>
                            <h2 id="elev8-preview-title"><?php esc_html_e('What customers see', 'elev8-os'); ?></h2>
                        </div>
                    </div>
                    <div class="elev8-public-preview-frame">
                        <?php echo do_shortcode('[elev8_artist_profile artist="' . esc_attr($slug) . '"]'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                    </div>
                </section>

                <script>
                (function(){
                    var button=document.querySelector('.elev8-copy-public-link');
                    if(!button){return;}
                    button.addEventListener('click',function(){
                        var link=this.getAttribute('data-link');
                        if(navigator.clipboard){
                            navigator.clipboard.writeText(link).then(function(){button.textContent='<?php echo esc_js(__('Copied!', 'elev8-os')); ?>';setTimeout(function(){button.textContent='<?php echo esc_js(__('Copy Link', 'elev8-os')); ?>';},1500);});
                        }else{window.prompt('<?php echo esc_js(__('Copy this link:', 'elev8-os')); ?>',link);}
                    });
                }());
                </script>
            <?php endif; ?>
        </div>
        <?php
        return (string) ob_get_clean();
    }


    public static function edit_website_shortcode(): string {
        if (!is_user_logged_in()) {
            return sprintf(
                '<div class="elev8-dashboard-login"><p>%1$s</p><p><a class="button" href="%2$s">%3$s</a></p></div>',
                esc_html__('Please log in to manage your artist website.', 'elev8-os'),
                esc_url(wp_login_url(self::edit_website_url())),
                esc_html__('Log In', 'elev8-os')
            );
        }

        $user = wp_get_current_user();
        $artist = self::find_artist_for_user($user);
        ob_start();
        ?>
        <div class="elev8-artist-dashboard elev8-edit-website">
            <?php self::render_navigation('edit_website'); ?>
            <header class="elev8-dashboard-header elev8-website-header">
                <div>
                    <p class="elev8-eyebrow"><?php esc_html_e('Artist Portal', 'elev8-os'); ?></p>
                    <h1><?php esc_html_e('Manage My Website', 'elev8-os'); ?></h1>
                    <p><?php esc_html_e('Update the information customers see on your public artist page.', 'elev8-os'); ?></p>
                </div>
                <span class="elev8-dashboard-badge"><?php esc_html_e('Artist managed', 'elev8-os'); ?></span>
            </header>

            <?php if (isset($_GET['elev8_saved']) && $_GET['elev8_saved'] === '1') : ?>
                <div class="elev8-save-notice" role="status"><?php esc_html_e('Your website was updated successfully.', 'elev8-os'); ?></div>
            <?php endif; ?>

            <?php if (!$artist) : ?>
                <div class="elev8-dashboard-warning">
                    <p><strong><?php esc_html_e('Your account is not connected to an Amelia artist.', 'elev8-os'); ?></strong><br><?php esc_html_e('Ask an administrator to map this WordPress account to the correct Amelia employee.', 'elev8-os'); ?></p>
                </div>
            <?php else : ?>
                <?php
                $employee_id = absint($artist['id'] ?? 0);
                $profiles = self::get_profiles();
                $profile = isset($profiles[$employee_id]) && is_array($profiles[$employee_id]) ? $profiles[$employee_id] : [];
                $slug = self::artist_slug($artist);
                $public_url = home_url('/artists/' . $slug . '/');
                $artist_name = trim((string) ($artist['firstName'] ?? '') . ' ' . (string) ($artist['lastName'] ?? ''));
                if ($artist_name === '') {
                    $artist_name = $user->display_name ?: __('Artist', 'elev8-os');
                }
                ?>
                <div class="elev8-website-builder">
                <form class="elev8-manage-website-form" method="post" enctype="multipart/form-data" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                    <input type="hidden" name="action" value="elev8_os_artist_save_website">
                    <input type="hidden" name="employee_id" value="<?php echo esc_attr((string) $employee_id); ?>">
                    <?php wp_nonce_field('elev8_os_artist_save_website_' . $employee_id); ?>

                    <section class="elev8-editor-section">
                        <div class="elev8-editor-heading">
                            <div><p class="elev8-eyebrow"><?php esc_html_e('Introduction', 'elev8-os'); ?></p><h2><?php esc_html_e('About You', 'elev8-os'); ?></h2></div>
                            <a href="<?php echo esc_url($public_url); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e('View public page', 'elev8-os'); ?></a>
                        </div>
                        <div class="elev8-form-grid">
                            <?php self::render_text_input('medium', __('Art form or medium', 'elev8-os'), $profile, __('Example: Painting, stained glass, pottery', 'elev8-os')); ?>
                            <?php self::render_text_input('specialties', __('Teaching specialties', 'elev8-os'), $profile, __('Example: Beginner watercolor and mixed media', 'elev8-os')); ?>
                            <?php self::render_text_input('experience', __('Experience', 'elev8-os'), $profile, __('Example: Teaching for 12 years', 'elev8-os')); ?>
                            <?php self::render_text_input('website', __('Personal website', 'elev8-os'), $profile, 'https://', 'url'); ?>
                        </div>
                        <label class="elev8-field elev8-field-full">
                            <span><?php esc_html_e('Artist bio', 'elev8-os'); ?></span>
                            <textarea name="bio" rows="7" placeholder="<?php esc_attr_e('Tell customers about your work, your story, and what they can expect from your classes.', 'elev8-os'); ?>"><?php echo esc_textarea((string) ($profile['bio'] ?? '')); ?></textarea>
                        </label>
                    </section>

                    <section class="elev8-editor-section">
                        <div class="elev8-editor-heading"><div><p class="elev8-eyebrow"><?php esc_html_e('Images', 'elev8-os'); ?></p><h2><?php esc_html_e('Profile Images', 'elev8-os'); ?></h2></div></div>
                        <div class="elev8-form-grid elev8-image-upload-grid">
                            <?php self::render_image_upload('profile_photo', 'profile_photo_upload', __('Profile photo', 'elev8-os'), $profile, __('Use a clear square or portrait image of yourself or your logo.', 'elev8-os')); ?>
                            <?php self::render_image_upload('cover_image', 'cover_image_upload', __('Hero / cover image', 'elev8-os'), $profile, __('Use a wide image that represents your art and fills the top of your public page.', 'elev8-os')); ?>
                        </div>
                        <p class="elev8-editor-help"><?php esc_html_e('Uploaded images are saved securely in the WordPress Media Library. Products shown on your public page come directly from My Artwork.', 'elev8-os'); ?></p>
                    </section>

                    <section class="elev8-editor-section elev8-artist-brand-section">
                        <div class="elev8-editor-heading"><div><p class="elev8-eyebrow"><?php esc_html_e('Artist Brand', 'elev8-os'); ?></p><h2><?php esc_html_e('My Email Identity', 'elev8-os'); ?></h2></div></div>
                        <p class="elev8-section-help"><?php esc_html_e('Your identity appears inside the official Elev8 Arts email design. The organization logo, mission, class links, event links, and footer remain controlled by Elev8 Arts.', 'elev8-os'); ?></p>
                        <label class="elev8-public-toggle">
                            <input type="checkbox" name="artist_email_brand_enabled" value="1" <?php checked(!isset($profile['artist_email_brand_enabled']) || !empty($profile['artist_email_brand_enabled'])); ?>>
                            <span><strong><?php esc_html_e('Include my artist identity in campaigns', 'elev8-os'); ?></strong><small><?php esc_html_e('Adds your name, image, short story, links, and signature when you create a campaign.', 'elev8-os'); ?></small></span>
                        </label>
                        <div class="elev8-form-grid">
                            <?php self::render_text_input('artist_brand_title', __('Artist heading', 'elev8-os'), $profile, __('Featured Artist', 'elev8-os')); ?>
                            <?php self::render_text_input('artist_email_signature', __('Email signature', 'elev8-os'), $profile, $artist_name); ?>
                            <label class="elev8-field"><span><?php esc_html_e('Artist accent color', 'elev8-os'); ?></span><input type="color" name="artist_brand_color" value="<?php echo esc_attr((string) ($profile['artist_brand_color'] ?? '#ff7a00')); ?>"></label>
                        </div>
                        <label class="elev8-field elev8-field-full"><span><?php esc_html_e('Short email introduction', 'elev8-os'); ?></span><textarea name="artist_email_bio" rows="4" placeholder="<?php esc_attr_e('A short, customer-friendly introduction to you and your work.', 'elev8-os'); ?>"><?php echo esc_textarea((string) ($profile['artist_email_bio'] ?? '')); ?></textarea></label>
                        <div class="elev8-form-grid elev8-image-upload-grid">
                            <?php self::render_image_upload('artist_logo', 'artist_logo_upload', __('Artist logo (optional)', 'elev8-os'), $profile, __('Use your personal artist logo. If blank, your profile photo is used.', 'elev8-os')); ?>
                        </div>
                    </section>

                    <section class="elev8-editor-section">
                        <div class="elev8-editor-heading"><div><p class="elev8-eyebrow"><?php esc_html_e('Connections', 'elev8-os'); ?></p><h2><?php esc_html_e('Social and Contact Links', 'elev8-os'); ?></h2></div></div>
                        <div class="elev8-repeat-grid">
                            <?php for ($i = 1; $i <= 4; $i++) : ?>
                                <div class="elev8-link-pair">
                                    <?php self::render_text_input('social_' . $i . '_name', sprintf(__('Social link %d name', 'elev8-os'), $i), $profile, __('Instagram', 'elev8-os')); ?>
                                    <?php self::render_text_input('social_' . $i . '_url', sprintf(__('Social link %d URL', 'elev8-os'), $i), $profile, 'https://', 'url'); ?>
                                </div>
                            <?php endfor; ?>
                        </div>
                        <div class="elev8-repeat-grid">
                            <?php for ($i = 1; $i <= 4; $i++) : ?>
                                <div class="elev8-link-pair">
                                    <?php self::render_text_input('contact_' . $i . '_name', sprintf(__('Contact %d name', 'elev8-os'), $i), $profile, __('Email me', 'elev8-os')); ?>
                                    <?php self::render_text_input('contact_' . $i . '_url', sprintf(__('Contact %d value', 'elev8-os'), $i), $profile, __('email@example.com, phone number, or webpage', 'elev8-os')); ?>
                                </div>
                            <?php endfor; ?>
                        </div>
                    </section>

                    <section class="elev8-editor-section">
                        <div class="elev8-editor-heading"><div><p class="elev8-eyebrow"><?php esc_html_e('Support', 'elev8-os'); ?></p><h2><?php esc_html_e('Payment and Tip Links', 'elev8-os'); ?></h2></div></div>
                        <p class="elev8-section-help"><?php esc_html_e('Add optional public links such as Venmo, PayPal, Cash App, Patreon, or a tip page.', 'elev8-os'); ?></p>
                        <div class="elev8-repeat-grid">
                            <?php for ($i = 1; $i <= 4; $i++) : ?>
                                <div class="elev8-link-pair">
                                    <?php self::render_text_input('payment_' . $i . '_name', sprintf(__('Payment link %d name', 'elev8-os'), $i), $profile, __('Venmo', 'elev8-os')); ?>
                                    <?php self::render_text_input('payment_' . $i . '_url', sprintf(__('Payment link %d URL', 'elev8-os'), $i), $profile, 'https://'); ?>
                                </div>
                            <?php endfor; ?>
                        </div>
                    </section>

                    <section class="elev8-editor-section">
                        <div class="elev8-editor-heading"><div><p class="elev8-eyebrow"><?php esc_html_e('Bookings', 'elev8-os'); ?></p><h2><?php esc_html_e('Book a Class Button', 'elev8-os'); ?></h2></div></div>
                        <div class="elev8-form-grid">
                            <?php self::render_text_input('booking_url', __('Booking page URL', 'elev8-os'), $profile, 'https://', 'url'); ?>
                            <?php self::render_text_input('booking_button_label', __('Button text', 'elev8-os'), $profile, __('Book Now with This Artist', 'elev8-os')); ?>
                        </div>
                        <label class="elev8-public-toggle">
                            <input type="checkbox" name="public_enabled" value="1" <?php checked(!empty($profile['public_enabled'])); ?>>
                            <span><strong><?php esc_html_e('Make my public artist page active', 'elev8-os'); ?></strong><small><?php esc_html_e('Turn this off only when you do not want customers to see your page.', 'elev8-os'); ?></small></span>
                        </label>
                    </section>

                    <div class="elev8-editor-actions">
                        <a class="elev8-secondary-button" href="<?php echo esc_url(self::website_url()); ?>"><?php esc_html_e('Cancel', 'elev8-os'); ?></a>
                        <button class="elev8-primary-button" type="submit"><?php esc_html_e('Save My Website', 'elev8-os'); ?></button>
                    </div>
                </form>

                <aside class="elev8-live-preview-panel" aria-labelledby="elev8-live-preview-heading">
                    <div class="elev8-live-preview-heading">
                        <div>
                            <p class="elev8-eyebrow"><?php esc_html_e('Live preview', 'elev8-os'); ?></p>
                            <h2 id="elev8-live-preview-heading"><?php esc_html_e('Your Public Artist Website', 'elev8-os'); ?></h2>
                            <p><?php esc_html_e('Changes appear here instantly. Save when you are ready to publish them.', 'elev8-os'); ?></p>
                        </div>
                        <span class="elev8-preview-status"><?php esc_html_e('Preview only', 'elev8-os'); ?></span>
                    </div>

                    <div class="elev8-live-profile-preview" data-artist-name="<?php echo esc_attr($artist_name); ?>">
                        <div class="elev8-live-cover" data-preview-cover<?php echo !empty($profile['cover_image']) ? ' style="background-image:url(' . esc_url($profile['cover_image']) . ')"' : ''; ?>>
                            <div class="elev8-live-cover-overlay"></div>
                        </div>
                        <div class="elev8-live-profile-body">
                            <div class="elev8-live-profile-head">
                                <div class="elev8-live-avatar" data-preview-avatar>
                                    <?php if (!empty($profile['profile_photo'])) : ?>
                                        <img src="<?php echo esc_url($profile['profile_photo']); ?>" alt="">
                                    <?php else : ?>
                                        <span><?php echo esc_html(strtoupper(substr($artist_name, 0, 1))); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div>
                                    <h3 data-preview-name><?php echo esc_html($artist_name); ?></h3>
                                    <p data-preview-medium><?php echo esc_html((string) ($profile['medium'] ?? __('Artist and Instructor', 'elev8-os'))); ?></p>
                                </div>
                            </div>

                            <div class="elev8-live-bio">
                                <h4><?php esc_html_e('About', 'elev8-os'); ?></h4>
                                <p data-preview-bio><?php echo esc_html((string) ($profile['bio'] ?? __('Your artist story will appear here.', 'elev8-os'))); ?></p>
                            </div>

                            <div class="elev8-live-details">
                                <div><span><?php esc_html_e('Specialties', 'elev8-os'); ?></span><strong data-preview-specialties><?php echo esc_html((string) ($profile['specialties'] ?? __('Not added yet', 'elev8-os'))); ?></strong></div>
                                <div><span><?php esc_html_e('Experience', 'elev8-os'); ?></span><strong data-preview-experience><?php echo esc_html((string) ($profile['experience'] ?? __('Not added yet', 'elev8-os'))); ?></strong></div>
                            </div>

                            <div class="elev8-live-store-note"><?php esc_html_e('Available products from My Artwork appear here automatically.', 'elev8-os'); ?></div>
                            <div class="elev8-live-links" data-preview-links></div>
                            <a class="elev8-live-book-button" data-preview-book href="#"><?php echo esc_html((string) ($profile['booking_button_label'] ?? __('Book Now with This Artist', 'elev8-os'))); ?></a>
                        </div>
                    </div>
                    <p class="elev8-preview-note"><?php esc_html_e('This preview reflects the content and structure of the public page. Your WordPress theme may add its own header, footer, and spacing.', 'elev8-os'); ?></p>
                </aside>
                </div>
            <?php endif; ?>
        </div>
        <?php
        return (string) ob_get_clean();
    }

    public static function save_artist_website(): void {
        if (!is_user_logged_in()) {
            auth_redirect();
        }

        $user = wp_get_current_user();
        $artist = self::find_artist_for_user($user);
        $employee_id = isset($_POST['employee_id']) ? absint($_POST['employee_id']) : 0;
        $mapped_id = $artist ? absint($artist['id'] ?? 0) : 0;

        if ($employee_id < 1 || $mapped_id !== $employee_id) {
            wp_die(esc_html__('You do not have permission to edit this artist website.', 'elev8-os'));
        }

        check_admin_referer('elev8_os_artist_save_website_' . $employee_id);

        $profiles = self::get_profiles();
        $existing = isset($profiles[$employee_id]) && is_array($profiles[$employee_id]) ? $profiles[$employee_id] : [];
        $editable = [
            'bio' => 'textarea',
            'medium' => 'text',
            'specialties' => 'text',
            'experience' => 'text',
            'website' => 'url',
            'booking_url' => 'url',
            'booking_button_label' => 'text',
            'artist_brand_title' => 'text',
            'artist_email_signature' => 'text',
            'artist_brand_color' => 'color',
            'artist_email_bio' => 'textarea',
        ];

        foreach ($editable as $key => $type) {
            $raw = isset($_POST[$key]) ? wp_unslash($_POST[$key]) : '';
            if ($type === 'textarea') {
                $existing[$key] = sanitize_textarea_field($raw);
            } elseif ($type === 'url') {
                $existing[$key] = esc_url_raw($raw);
            } elseif ($type === 'color') {
                $existing[$key] = sanitize_hex_color($raw) ?: '#ff7a00';
            } else {
                $existing[$key] = sanitize_text_field($raw);
            }
        }

        $existing['profile_photo'] = self::process_image_upload(
            'profile_photo_upload',
            isset($_POST['profile_photo']) ? esc_url_raw(wp_unslash($_POST['profile_photo'])) : (string) ($existing['profile_photo'] ?? ''),
            isset($_POST['remove_profile_photo'])
        );
        $existing['cover_image'] = self::process_image_upload(
            'cover_image_upload',
            isset($_POST['cover_image']) ? esc_url_raw(wp_unslash($_POST['cover_image'])) : (string) ($existing['cover_image'] ?? ''),
            isset($_POST['remove_cover_image'])
        );
        $existing['artist_logo'] = self::process_image_upload(
            'artist_logo_upload',
            isset($_POST['artist_logo']) ? esc_url_raw(wp_unslash($_POST['artist_logo'])) : (string) ($existing['artist_logo'] ?? ''),
            isset($_POST['remove_artist_logo'])
        );

        for ($i = 1; $i <= 4; $i++) {
            $existing['social_' . $i . '_name'] = isset($_POST['social_' . $i . '_name']) ? sanitize_text_field(wp_unslash($_POST['social_' . $i . '_name'])) : '';
            $existing['social_' . $i . '_url'] = isset($_POST['social_' . $i . '_url']) ? esc_url_raw(wp_unslash($_POST['social_' . $i . '_url'])) : '';
            $existing['contact_' . $i . '_name'] = isset($_POST['contact_' . $i . '_name']) ? sanitize_text_field(wp_unslash($_POST['contact_' . $i . '_name'])) : '';
            $existing['contact_' . $i . '_url'] = isset($_POST['contact_' . $i . '_url']) ? self::sanitize_contact_value(wp_unslash($_POST['contact_' . $i . '_url'])) : '';
            $existing['payment_' . $i . '_name'] = isset($_POST['payment_' . $i . '_name']) ? sanitize_text_field(wp_unslash($_POST['payment_' . $i . '_name'])) : '';
            $existing['payment_' . $i . '_url'] = isset($_POST['payment_' . $i . '_url']) ? self::sanitize_public_value(wp_unslash($_POST['payment_' . $i . '_url'])) : '';
        }

        $existing['social'] = (string) ($existing['social_1_url'] ?? '');
        $existing['public_enabled'] = isset($_POST['public_enabled']) ? 1 : 0;
        $existing['artist_email_brand_enabled'] = isset($_POST['artist_email_brand_enabled']) ? 1 : 0;
        $existing['status'] = isset($existing['status']) && $existing['status'] === 'inactive' ? 'inactive' : 'active';
        $existing['booking_destination'] = isset($existing['booking_destination']) ? $existing['booking_destination'] : 'custom';

        $profiles[$employee_id] = $existing;
        update_option(self::PROFILES_OPTION, $profiles, false);
        wp_cache_delete(self::PROFILES_OPTION, 'options');

        $slug = self::artist_slug($artist);
        $public_url = home_url('/artists/' . $slug . '/');
        if (function_exists('clean_url_cache')) {
            clean_url_cache($public_url);
        }
        do_action('litespeed_purge_url', $public_url);
        do_action('litespeed_purge_all');

        wp_safe_redirect(add_query_arg('elev8_saved', '1', self::edit_website_url()));
        exit;
    }

    private static function edit_website_url(): string {
        return Elev8_OS_Portal_Page_Manager::get_url('edit_website');
    }

    private static function is_edit_website_page(): bool {
        return Elev8_OS_Portal_Page_Manager::is_current_page('edit_website');
    }

    /** @return array<int,array<string,mixed>> */
    private static function get_profiles(): array {
        $profiles = get_option(self::PROFILES_OPTION, []);
        return is_array($profiles) ? $profiles : [];
    }

    /** @param array<string,mixed> $profile */
    private static function render_image_upload(string $url_name, string $file_name, string $label, array $profile, string $help): void {
        $url = esc_url_raw((string) ($profile[$url_name] ?? ''));
        ?>
        <div class="elev8-field elev8-image-upload-field">
            <span><?php echo esc_html($label); ?></span>
            <?php if ($url !== '') : ?>
                <div class="elev8-current-image">
                    <img src="<?php echo esc_url($url); ?>" alt="">
                    <label><input type="checkbox" name="remove_<?php echo esc_attr($url_name); ?>" value="1"> <?php esc_html_e('Remove current image', 'elev8-os'); ?></label>
                </div>
            <?php endif; ?>
            <input type="file" name="<?php echo esc_attr($file_name); ?>" accept="image/*">
            <small><?php echo esc_html($help); ?></small>
            <details class="elev8-advanced-image-url">
                <summary><?php esc_html_e('Advanced: use an image URL', 'elev8-os'); ?></summary>
                <input type="url" name="<?php echo esc_attr($url_name); ?>" value="<?php echo esc_attr($url); ?>" placeholder="https://">
            </details>
        </div>
        <?php
    }

    /** Save a front-end artist image into the WordPress Media Library. */
    private static function process_image_upload(string $field, string $current_url, bool $remove): string {
        if ($remove) {
            return '';
        }

        if (empty($_FILES[$field]) || !is_array($_FILES[$field]) || (int) ($_FILES[$field]['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
            return esc_url_raw($current_url);
        }

        if ((int) ($_FILES[$field]['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK) {
            return esc_url_raw($current_url);
        }

        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';

        $attachment_id = media_handle_upload($field, 0);
        if (is_wp_error($attachment_id)) {
            return esc_url_raw($current_url);
        }

        $url = wp_get_attachment_image_url((int) $attachment_id, 'full');
        return $url ? esc_url_raw($url) : esc_url_raw($current_url);
    }

    private static function render_text_input(string $name, string $label, array $profile, string $placeholder = '', string $type = 'text'): void {
        ?>
        <label class="elev8-field">
            <span><?php echo esc_html($label); ?></span>
            <input type="<?php echo esc_attr($type); ?>" name="<?php echo esc_attr($name); ?>" value="<?php echo esc_attr((string) ($profile[$name] ?? '')); ?>" placeholder="<?php echo esc_attr($placeholder); ?>">
        </label>
        <?php
    }

    private static function sanitize_public_value(string $value): string {
        $value = trim($value);
        if ($value === '') {
            return '';
        }
        if (preg_match('/^(mailto:|tel:)/i', $value)) {
            return sanitize_text_field($value);
        }
        if (!preg_match('#^https?://#i', $value)) {
            $value = 'https://' . ltrim($value, '/');
        }
        return esc_url_raw($value, ['http', 'https']);
    }

    private static function sanitize_contact_value(string $value): string {
        $value = trim($value);
        if ($value === '') {
            return '';
        }
        if (is_email($value)) {
            return 'mailto:' . sanitize_email($value);
        }
        $phone = preg_replace('/[^\d+]/', '', $value);
        if ($phone !== '' && preg_match('/^\+?\d{7,15}$/', $phone)) {
            return 'tel:' . $phone;
        }
        return self::sanitize_public_value($value);
    }

    private static function website_url(): string {
        return Elev8_OS_Portal_Page_Manager::get_url('website');
    }

    private static function is_website_page(): bool {
        return Elev8_OS_Portal_Page_Manager::is_current_page('website');
    }

    private static function edit_profile_url(WP_User $user): string {
        $saved = esc_url_raw((string) get_user_meta($user->ID, self::META_EDIT_PAGE, true));
        if ($saved !== '') {
            return $saved;
        }
        return get_edit_user_link($user->ID) ?: admin_url('profile.php');
    }

    /** @return array<string,mixed>|null */
    public static function find_artist_for_user(WP_User $user): ?array {
        return Elev8_OS_Identity_Service::artist_for_user($user);
    }

    /** @param array<string,mixed> $artist */
    private static function artist_slug(array $artist): string {
        $name = trim((string) ($artist['firstName'] ?? '') . ' ' . (string) ($artist['lastName'] ?? ''));
        if ($name === '') {
            $name = 'artist-' . absint($artist['id'] ?? 0);
        }
        return sanitize_title($name);
    }

    /** @return string[] */
    private static function table_columns(string $table): array {
        global $wpdb;
        $columns = $wpdb->get_col("DESCRIBE `{$table}`", 0);
        return is_array($columns) ? array_map('strval', $columns) : [];
    }

    private static function table_exists(string $table): bool {
        global $wpdb;
        $found = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table));
        return $found === $table;
    }

    /**
     * @return array<string,array<string,mixed>>
     */
    public static function navigation_items(?WP_User $user = null): array {
        $user = $user ?: wp_get_current_user();

        $dashboard_url = Elev8_OS_Portal_Page_Manager::get_url('dashboard');
        $website_url = self::website_url();
        $public_url = esc_url_raw((string) get_user_meta($user->ID, self::META_PUBLIC_PAGE, true));
        $edit_url = self::edit_website_url();
        $classes_url = Elev8_OS_Portal_Page_Manager::get_url('classes');
        $artwork_url = Elev8_OS_Portal_Page_Manager::get_url('artwork');
        $students_url = Elev8_OS_Portal_Page_Manager::get_url('students');
        $growth_studio_url = Elev8_OS_Portal_Page_Manager::get_url('growth_studio');
        $content_studio_url = Elev8_OS_Portal_Page_Manager::get_url('content_studio');
        $marketing_url = Elev8_OS_Portal_Page_Manager::get_url('marketing');
        $waitlist_url = Elev8_OS_Portal_Page_Manager::get_url('waitlist');
        $booking_url = esc_url_raw((string) get_user_meta($user->ID, self::META_BOOKING, true));

        return [
            'dashboard' => [
                'label' => __('Dashboard', 'elev8-os'),
                'icon' => 'dashboard',
                'url' => $dashboard_url,
                'enabled' => true,
            ],
            'classes' => [
                'label' => __('My Classes', 'elev8-os'),
                'icon' => 'calendar-alt',
                'url' => $classes_url,
                'enabled' => true,
            ],
            'artwork' => [
                'label' => __('My Artwork', 'elev8-os'),
                'icon' => 'format-image',
                'url' => $artwork_url,
                'enabled' => true,
            ],
            'website' => [
                'label' => __('My Website', 'elev8-os'),
                'icon' => 'admin-site-alt3',
                'url' => $website_url,
                'enabled' => true,
            ],
            'edit_website' => [
                'label' => __('Edit Website', 'elev8-os'),
                'icon' => 'edit-page',
                'url' => $edit_url,
                'enabled' => $edit_url !== '',
            ],
            'booking' => [
                'label' => __('Booking Link', 'elev8-os'),
                'icon' => 'admin-links',
                'url' => $booking_url,
                'enabled' => $booking_url !== '',
                'new_tab' => true,
            ],
            'earnings' => [
                'label' => __('Earnings', 'elev8-os'),
                'icon' => 'money-alt',
                'url' => '',
                'enabled' => false,
            ],
            'students' => [
                'label' => __('Students', 'elev8-os'),
                'icon' => 'groups',
                'url' => $students_url,
                'enabled' => true,
            ],
            'growth_studio' => [
                'label' => __('Growth Studio', 'elev8-os'),
                'icon' => 'megaphone',
                'url' => $growth_studio_url,
                'enabled' => true,
            ],
            'waitlist' => [
                'label' => __('Class Requests', 'elev8-os'),
                'icon' => 'list-view',
                'url' => $waitlist_url,
                'enabled' => true,
            ],
            'referrals' => [
                'label' => __('Referrals', 'elev8-os'),
                'icon' => 'megaphone',
                'url' => '',
                'enabled' => false,
            ],
            'tax_documents' => [
                'label' => __('Tax Documents', 'elev8-os'),
                'icon' => 'media-document',
                'url' => '',
                'enabled' => false,
            ],
            'settings' => [
                'label' => __('Settings', 'elev8-os'),
                'icon' => 'admin-generic',
                'url' => '',
                'enabled' => false,
            ],
        ];
    }


    /**
     * Render the reusable shortcut launcher. Initially enabled on the dashboard.
     * Both desktop and mobile launchers use the same central navigation data.
     */
    public static function render_shortcut_launcher(string $active = 'dashboard'): void {
        $items = self::navigation_items();
        $print_url = Elev8_OS_Portal_Page_Manager::get_url('print_center');
        $items['print_center'] = [
            'label' => __('Print Center', 'elev8-os'),
            'icon' => 'media-document',
            'url' => $print_url,
            'enabled' => $print_url !== '',
        ];

        $primary_keys = ['dashboard', 'growth_studio', 'artwork', 'classes'];
        ?>
        <div class="elev8-shortcut-sentinel" aria-hidden="true"></div>
        <div class="elev8-shortcut-bar" data-elev8-shortcut-bar aria-hidden="true">
            <div class="elev8-shortcut-bar-inner">
                <a class="elev8-shortcut-brand" href="<?php echo esc_url($items['dashboard']['url']); ?>" aria-label="<?php esc_attr_e('Elev8 OS Dashboard', 'elev8-os'); ?>">
                    <span class="elev8-shortcut-brand-mark">E8</span><span><?php esc_html_e('Elev8 OS', 'elev8-os'); ?></span>
                </a>
                <div class="elev8-shortcut-primary">
                    <?php foreach ($primary_keys as $key) : $item = $items[$key] ?? null; if (!$item || empty($item['enabled'])) { continue; } ?>
                        <a class="elev8-shortcut-link<?php echo $key === $active ? ' is-active' : ''; ?>" href="<?php echo esc_url($item['url']); ?>">
                            <span class="dashicons dashicons-<?php echo esc_attr($item['icon']); ?>" aria-hidden="true"></span>
                            <span><?php echo esc_html($item['label']); ?></span>
                        </a>
                    <?php endforeach; ?>
                    <button class="elev8-shortcut-more" type="button" data-elev8-shortcut-open aria-haspopup="dialog" aria-controls="elev8-shortcut-dialog">
                        <span class="dashicons dashicons-menu-alt3" aria-hidden="true"></span><span><?php esc_html_e('More', 'elev8-os'); ?></span>
                    </button>
                </div>
            </div>
        </div>

        <button class="elev8-shortcut-fab" type="button" data-elev8-shortcut-open aria-haspopup="dialog" aria-controls="elev8-shortcut-dialog">
            <span class="dashicons dashicons-menu" aria-hidden="true"></span><span><?php esc_html_e('Shortcuts', 'elev8-os'); ?></span>
        </button>

        <div class="elev8-shortcut-dialog" id="elev8-shortcut-dialog" data-elev8-shortcut-dialog hidden>
            <button class="elev8-shortcut-backdrop" type="button" data-elev8-shortcut-close aria-label="<?php esc_attr_e('Close shortcuts', 'elev8-os'); ?>"></button>
            <section class="elev8-shortcut-panel" role="dialog" aria-modal="true" aria-labelledby="elev8-shortcut-title">
                <header>
                    <div><p><?php esc_html_e('Artist Portal', 'elev8-os'); ?></p><h2 id="elev8-shortcut-title"><?php esc_html_e('Where do you want to go?', 'elev8-os'); ?></h2></div>
                    <button type="button" class="elev8-shortcut-close" data-elev8-shortcut-close aria-label="<?php esc_attr_e('Close shortcuts', 'elev8-os'); ?>"><span class="dashicons dashicons-no-alt" aria-hidden="true"></span></button>
                </header>
                <div class="elev8-shortcut-groups">
                    <?php
                    $groups = [
                        __('Create & Grow', 'elev8-os') => ['growth_studio', 'artwork', 'website', 'edit_website', 'print_center'],
                        __('Classes', 'elev8-os') => ['classes', 'students', 'waitlist'],
                        __('Account', 'elev8-os') => ['dashboard'],
                    ];
                    foreach ($groups as $group_label => $keys) : ?>
                        <div class="elev8-shortcut-group"><h3><?php echo esc_html($group_label); ?></h3><div>
                        <?php foreach ($keys as $key) : $item = $items[$key] ?? null; if (!$item || empty($item['enabled'])) { continue; } ?>
                            <a class="elev8-shortcut-card<?php echo $key === $active ? ' is-active' : ''; ?>" href="<?php echo esc_url($item['url']); ?>">
                                <span class="dashicons dashicons-<?php echo esc_attr($item['icon']); ?>" aria-hidden="true"></span><span><?php echo esc_html($item['label']); ?></span>
                            </a>
                        <?php endforeach; ?>
                        </div></div>
                    <?php endforeach; ?>
                </div>
            </section>
        </div>
        <?php
    }

    public static function render_navigation(string $active = 'dashboard'): void {
        $items = self::navigation_items();
        $user = wp_get_current_user();
        $site_links = self::site_navigation_items($user);
        ?>
        <nav class="elev8-site-nav" aria-label="<?php esc_attr_e('Elev8 Arts website navigation', 'elev8-os'); ?>">
            <div class="elev8-site-nav-links">
                <?php foreach ($site_links as $item) : ?>
                    <a class="elev8-site-nav-link<?php echo !empty($item['primary']) ? ' is-primary' : ''; ?>" href="<?php echo esc_url($item['url']); ?>"<?php echo !empty($item['new_tab']) ? ' target="_blank" rel="noopener noreferrer"' : ''; ?>>
                        <span class="dashicons dashicons-<?php echo esc_attr($item['icon']); ?>" aria-hidden="true"></span>
                        <span><?php echo esc_html($item['label']); ?></span>
                    </a>
                <?php endforeach; ?>
            </div>
        </nav>
        <nav class="elev8-portal-nav" aria-label="<?php esc_attr_e('Artist Portal', 'elev8-os'); ?>">
            <div class="elev8-portal-brand">
                <span class="elev8-portal-brand-mark">E8</span>
                <span>
                    <strong><?php esc_html_e('Elev8 OS', 'elev8-os'); ?></strong>
                    <small><?php esc_html_e('Artist Portal', 'elev8-os'); ?></small>
                </span>
            </div>

            <div class="elev8-portal-links">
                <?php foreach ($items as $key => $item) : ?>
                    <?php
                    if (empty($item['enabled'])) {
                        continue;
                    }
                    $classes = ['elev8-portal-link'];
                    if ($key === $active) {
                        $classes[] = 'is-active';
                    }
                    if (!$item['enabled']) {
                        $classes[] = 'is-disabled';
                    }
                    ?>
                    <?php if ($item['enabled']) : ?>
                        <a
                            class="<?php echo esc_attr(implode(' ', $classes)); ?>"
                            href="<?php echo esc_url($item['url']); ?>"
                            <?php echo !empty($item['new_tab']) ? 'target="_blank" rel="noopener noreferrer"' : ''; ?>
                        >
                            <span class="dashicons dashicons-<?php echo esc_attr($item['icon']); ?>" aria-hidden="true"></span>
                            <span><?php echo esc_html($item['label']); ?></span>
                        </a>
                    <?php else : ?>
                        <span class="<?php echo esc_attr(implode(' ', $classes)); ?>" aria-disabled="true">
                            <span class="dashicons dashicons-<?php echo esc_attr($item['icon']); ?>" aria-hidden="true"></span>
                            <span><?php echo esc_html($item['label']); ?></span>
                            <small><?php esc_html_e('Coming soon', 'elev8-os'); ?></small>
                        </span>
                    <?php endif; ?>
                <?php endforeach; ?>
            </div>
        </nav>
        <?php
    }


    /**
     * Website-facing destinations that help artists move between their private
     * workspace and the public Elev8 Arts experience without getting trapped.
     *
     * @return array<int,array<string,mixed>>
     */
    private static function site_navigation_items(WP_User $user): array {
        $public_url = esc_url_raw((string) get_user_meta($user->ID, self::META_PUBLIC_PAGE, true));
        if ($public_url === '') {
            $artist = self::find_artist_for_user($user);
            if (is_array($artist)) {
                $public_url = home_url('/artists/' . self::artist_slug($artist) . '/');
            }
        }

        $shop_url = function_exists('wc_get_page_permalink') ? (string) wc_get_page_permalink('shop') : '';
        if ($shop_url === '') {
            $shop_url = home_url('/shop/');
        }

        $items = [
            [
                'label' => __('Elev8 Arts Home', 'elev8-os'),
                'icon' => 'admin-home',
                'url' => home_url('/'),
                'new_tab' => false,
                'primary' => true,
            ],
        ];

        if ($public_url !== '') {
            $items[] = [
                'label' => __('My Public Artist Page', 'elev8-os'),
                'icon' => 'visibility',
                'url' => $public_url,
                'new_tab' => true,
                'primary' => false,
            ];
        }

        $items[] = [
            'label' => __('Book a Class', 'elev8-os'),
            'icon' => 'calendar-alt',
            'url' => home_url('/book-appointment/'),
            'new_tab' => true,
            'primary' => false,
        ];
        $items[] = [
            'label' => __('Events', 'elev8-os'),
            'icon' => 'megaphone',
            'url' => home_url('/elev8-events/'),
            'new_tab' => true,
            'primary' => false,
        ];
        $items[] = [
            'label' => __('Shop', 'elev8-os'),
            'icon' => 'cart',
            'url' => $shop_url,
            'new_tab' => true,
            'primary' => false,
        ];
        $items[] = [
            'label' => __('Log Out', 'elev8-os'),
            'icon' => 'exit',
            'url' => wp_logout_url(home_url('/')),
            'new_tab' => false,
            'primary' => false,
        ];

        return $items;
    }

    public static function render_profile_fields(WP_User $user): void {
        if (!current_user_can('edit_user', $user->ID)) {
            return;
        }

        wp_nonce_field('elev8_os_artist_portal_links', 'elev8_os_artist_portal_nonce');
        ?>
        <h2><?php esc_html_e('Elev8 OS Artist Portal Links', 'elev8-os'); ?></h2>
        <p><?php esc_html_e('These links control the working buttons shown in this artist’s portal.', 'elev8-os'); ?></p>

        <table class="form-table" role="presentation">
            <?php
            self::render_url_field($user, self::META_PUBLIC_PAGE, __('Public artist page', 'elev8-os'));
            self::render_url_field($user, self::META_EDIT_PAGE, __('Edit artist page', 'elev8-os'));
            self::render_url_field($user, self::META_CLASSES, __('My Classes page', 'elev8-os'));
            self::render_url_field($user, self::META_BOOKING, __('Booking link', 'elev8-os'));
            ?>
        </table>
        <?php
    }

    public static function save_profile_fields(int $user_id): void {
        if (!current_user_can('edit_user', $user_id)) {
            return;
        }

        if (
            empty($_POST['elev8_os_artist_portal_nonce']) ||
            !wp_verify_nonce(
                sanitize_text_field(wp_unslash($_POST['elev8_os_artist_portal_nonce'])),
                'elev8_os_artist_portal_links'
            )
        ) {
            return;
        }

        foreach ([
            self::META_PUBLIC_PAGE,
            self::META_EDIT_PAGE,
            self::META_CLASSES,
            self::META_BOOKING,
        ] as $meta_key) {
            $value = isset($_POST[$meta_key])
                ? esc_url_raw(wp_unslash($_POST[$meta_key]))
                : '';

            if ($value === '') {
                delete_user_meta($user_id, $meta_key);
            } else {
                update_user_meta($user_id, $meta_key, $value);
            }
        }
    }

    private static function render_url_field(WP_User $user, string $meta_key, string $label): void {
        $value = (string) get_user_meta($user->ID, $meta_key, true);
        ?>
        <tr>
            <th><label for="<?php echo esc_attr($meta_key); ?>"><?php echo esc_html($label); ?></label></th>
            <td>
                <input
                    type="url"
                    class="regular-text"
                    id="<?php echo esc_attr($meta_key); ?>"
                    name="<?php echo esc_attr($meta_key); ?>"
                    value="<?php echo esc_attr($value); ?>"
                    placeholder="https://"
                >
            </td>
        </tr>
        <?php
    }
}
